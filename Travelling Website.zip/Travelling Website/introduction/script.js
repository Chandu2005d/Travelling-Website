const questions = [
    {
        text: "What is the capital of Sri Lanka?",
        choices: ["Colombo", "Kandy", "Galle", "Jaffna"],
        correctAnswer: "Colombo"
    },
    {
        text: "Which body of water surrounds Sri Lanka?",
        choices: ["Indian Ocean", "Arabian Sea", "Bay of Bengal", "Laccadive Sea"],
        correctAnswer: "Indian Ocean"
    },
    {
        text: "What is the predominant religion in Sri Lanka?",
        choices: ["Islam", "Buddhism", "Christianity", "Hinduism"],
        correctAnswer: "Buddhism"
    },
    {
        text: "What is the highest mountain in Sri Lanka?",
        choices: ["Pidurutalagala", "Kirigalpotta", "Adam's Peak", "Knuckles Mountain Range"],
        correctAnswer: "Pidurutalagala"
    },
    {
        text: "Which is the largest city in Sri Lanka by population?",
        choices: ["Colombo", "Gampaha", "Jaffna", "Kandy"],
        correctAnswer: "Colombo"
    },
    {
        text: "What is the official language of Sri Lanka?",
        choices: ["Sinhala", "Tamil", "English", "All of the above"],
        correctAnswer: "All of the above"
    },
    {
        text: "Which year did Sri Lanka gain independence from British rule?",
        choices: ["1947", "1948", "1950", "1951"],
        correctAnswer: "1948"
    },
    {
        text: "What is the famous export product of Sri Lanka?",
        choices: ["Rubber", "Tea", "Textiles", "Electronics"],
        correctAnswer: "Tea"
    },
    {
        text: "What is the name of the national cricket team of Sri Lanka?",
        choices: ["The Lions", "The Tigers", "The Elephants", "The Jaguars"],
        correctAnswer: "The Lions"
    },
    {
        text: "Which historical site in Sri Lanka is known for its ancient rock fortress?",
        choices: ["Sigiriya", "Anuradhapura", "Polonnaruwa", "Dambulla"],
        correctAnswer: "Sigiriya"
    }
];


let currentQuestionIndex = 0;
let score = 0;
let countdownTimer;

const questionText = document.getElementById("question-text");
const choicesList = document.getElementById("choices-list");
const submitButton = document.getElementById("submit-button");
const resultArea = document.getElementById("result-area");
const scoreText = document.getElementById("score");

function startTimer() {
    let timeLeft = 10;
    countdownTimer = setInterval(() => {
        if (timeLeft >= 0) {
            questionText.textContent = `${questions[currentQuestionIndex].text} (Time Left: ${timeLeft} seconds)`;
            timeLeft--;
        } else {
            clearInterval(countdownTimer);
            submitQuiz(true);
        }
    }, 1000);
}

function displayQuestion() {
    clearInterval(countdownTimer);
    questionText.textContent = questions[currentQuestionIndex].text;
    choicesList.innerHTML = "";

    questions[currentQuestionIndex].choices.forEach((choice, index) => {
        const li = document.createElement("li");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "choice";
        radio.value = choice;
        radio.id = `choice${index}`;
        li.appendChild(radio);
        li.appendChild(document.createTextNode(choice));
        choicesList.appendChild(li);
    });

    startTimer();
}

function submitQuiz(outOfTime) {
    const selectedChoice = document.querySelector('input[name="choice"]:checked');

    if (!outOfTime && !selectedChoice) {
        alert("Please select an answer.");
        return;
    }

    if (!outOfTime && selectedChoice.value === questions[currentQuestionIndex].correctAnswer) {
        score++;
        scoreText.textContent = score;
        resultArea.textContent = "Correct";
    } else {
        resultArea.textContent = "Incorrect";
    }

    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    clearInterval(countdownTimer);
    questionText.textContent = "";
    choicesList.innerHTML = "";
    submitButton.style.display = "none";

    resultArea.textContent = `You scored ${score} out of ${questions.length} questions correctly.`;

    if (score === questions.length) {
        resultArea.classList.add("correct");
        resultArea.textContent += " Great job!";
    } else {
        resultArea.classList.add("incorrect");
    }

    displayQuizSummary();
}

function displayQuizSummary() {
    clearInterval(countdownTimer);
    submitButton.style.display = "none";

    const quizSummary = document.getElementById("quiz-summary");

    let summaryHTML = "<h2>Quiz Summary</h2>";

    questions.forEach((question, index) => {
        summaryHTML += `<p><strong>Question ${index + 1}:</strong> ${question.text}</p>`;
        summaryHTML += `<p><strong>Correct Answer:</strong> ${question.correctAnswer}</p>`;
        summaryHTML += "<p><strong>Choices:</strong><ul>";

        question.choices.forEach(choice => {
            summaryHTML += `<li>${choice}</li>`;
        });

        summaryHTML += "</ul></p>";
    });

    summaryHTML += '<button id="restart-button">Restart the Quiz</button>';
    summaryHTML += '<button id="share-button">Share your score</button>'; // Added share button

    quizSummary.innerHTML = summaryHTML;

    const restartButton = document.getElementById("restart-button");
    restartButton.addEventListener("click", () => {
        location.reload();
    });

    const shareButton = document.getElementById("share-button");
    const messageToCopy = `I scored ${score} out of ${questions.length} in the space quiz! Try it yourself!`;
    const facebookURL = "https://www.facebook.com";

shareButton.addEventListener("click", () => {
    navigator.clipboard.writeText(messageToCopy).then(() => {
        console.log('Message copied to clipboard: ' + messageToCopy);
        const copyNotification = document.createElement('p');
        copyNotification.textContent = 'Score copied to clipboard';
        quizSummary.appendChild(copyNotification);
        setTimeout(() => {
            copyNotification.style.display = 'none';
            window.open(facebookURL, '_blank');
        }, 1500); 
    }).catch(err => {
        console.error('Could not copy text: ', err);
    });
});

}

submitButton.addEventListener("click", () => submitQuiz(false));

displayQuestion();
